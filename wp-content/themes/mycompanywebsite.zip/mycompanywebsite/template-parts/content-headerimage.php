
<!--==================================
=            Header Image            =
===================================-->



    <div class="row">

      <div class="col-xs-12">

        <img class="title-image center-block img-responsive rounded-corners" src="<?php bloginfo('stylesheet_directory'); ?>/assets/img/guell-cropped.jpg" alt="guell park image" srcset="<?php bloginfo('stylesheet_directory'); ?>/assets/img/guell-medium.jpg 320w, <?php bloginfo('stylesheet_directory'); ?>/assets/img/guell-medium.jpg 640w, <?php bloginfo('stylesheet_directory'); ?>/assets/img/guell-cropped.jpg 1024w" sizes="(min-width: 300px) 50vw, (min-width: 700px) 70vw, 100vw">
      </div>
    </div>